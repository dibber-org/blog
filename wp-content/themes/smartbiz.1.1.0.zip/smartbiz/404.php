<?php get_header(); ?>

	<div id="content">
		<h2 class="pagetitle">Error 404: Page Not Found</h2>
		<p>We are terribly sorry, but the page you are looking for no longer exists.</p>
	</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>