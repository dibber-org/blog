	<div id="footer">
    
    	
        <p>Copyright 2008 <a href="<?php bloginfo("url");?>" id="blogTitle"> <?php bloginfo("title");?></a>. Designed by <a href="http://www.diamondsdesigners.com"> Diamonds</a> 
		Designers. Powered by <a href="http://www.wordpress.org"> WordPress</a>.</p>
    	<span class="rss"><a href="<?php bloginfo("rss2_url");?>">Posts RSS</a></span><span class="rss"><a href="<?php bloginfo('comments_rss2_url'); ?>">
		Comments RSS</a></span>

   <?php wp_footer();?> 
    
    </div><!-- end of footer-->


</div> <!-- end of website-->





</body>
</html>
