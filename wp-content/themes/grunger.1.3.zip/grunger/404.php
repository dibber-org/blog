
<?php get_header();?>
    
    <div style="clear:both"></div>
    
    <div id="content">
    
    
		<?php get_sidebar();?>
        
        
        <div id="right">
       
		
        
        	<div class="article">
            
            
                
                	
                    <div class="artTitle">
                    
                    	<h3>Ups! 404 Error!</h3>
                       
                    
                    </div> <!-- end of artTitle class-->
                    <div style="clear:both"></div>
              
                    <div class="text">
                    
                    
                   There was nothing found here....
                    
                    </div> <!-- end of text class-->
                
                	

                        
                    
                
            </div> <!-- end of article class-->
			
   
			<div style="text-align:center;">
<?php posts_nav_link(' &#183; ', 'previous page', 'next page'); ?>
</div>

        </div> <!-- end of right side-->
    
    
    </div> <!-- end of CONTENT-->


<div style="clear:both"></div>



<?php get_footer();?>